/**
 * 
 */
package com.eventizer.application;

import static java.time.format.DateTimeFormatter.ofPattern;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;

import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.eventizer.entity.common.LocalDateDeserializer;
import com.eventizer.entity.common.LocalDateSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * @author shysatya
 *
 */
@SpringBootApplication(scanBasePackages = { "com.eventizer.*" })
@EnableJpaRepositories(basePackages = "com.eventizer.repository.*")
public class EventizerApplication implements ServletContainerInitializer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(EventizerApplication.class, args);

	}

	@Override
	public void onStartup(Set<Class<?>> arg0, ServletContext arg1) throws ServletException {
		// TODO Auto-generated method stub

	}

	public static final DateTimeFormatter FORMATTER = ofPattern("dd-MM-yyyy HH:MM");
	
	public static final DateTimeFormatter TIMEFORMATTER = ofPattern("HH:MM");

/*@Bean
	@Primary
	public ObjectMapper serializingObjectMapper() {
		ObjectMapper objectMapper = new ObjectMapper();
		
		JavaTimeModule javaTimeModule = new JavaTimeModule();
		javaTimeModule.addSerializer(LocalDateTime.class, new LocalDateSerializer());
		javaTimeModule.addDeserializer(LocalDateTime.class, new LocalDateDeserializer());
		objectMapper.registerModule(javaTimeModule);
		return objectMapper;
	}*/

}
