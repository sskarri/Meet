/**
 * 
 */
package com.eventizer.entity.common;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author shysatya
 *
 */
@Document(collection="accounts")
public class Account extends EntityId{
	
	
	/**
	 * @return the accountName
	 */
	public String getAccountName() {
		return accountName;
	}

	/**
	 * @param accountName the accountName to set
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	private String accountName;
	
	private String location;
	
	

}
