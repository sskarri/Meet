/**
 * 
 */
package com.eventizer.entity.common;

import javax.persistence.Column;
import javax.persistence.Entity;


/**
 * @author shysatya
 *
 */
@Entity(name="accounts")
public class Account extends EntityId{
	
	
	/**
	 * @return the accountName
	 */
	public String getAccountName() {
		return accountName;
	}

	/**
	 * @param accountName the accountName to set
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	@Column(name="accountName")
	private String accountName;
	@Column(name="location")
	private String location;
	
	

}
