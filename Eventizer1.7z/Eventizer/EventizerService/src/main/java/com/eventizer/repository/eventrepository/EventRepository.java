/**
 * 
 */
package com.eventizer.repository.eventrepository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.eventizer.entity.common.Event;

/**
 * @author shysatya
 *
 */
public interface EventRepository  extends MongoRepository<Event,Integer>{

}
