/**
 * 
 */
package com.eventizer.controller.event;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eventizer.entity.common.Event;

/**
 * @author shysatya
 *
 */
@RestController
@RequestMapping("/event")
public class EventsController {

	
	@RequestMapping("/createEvent")
	public String createEvent(@RequestBody Event event){
		
		
		return "Success";
	}
	
}
