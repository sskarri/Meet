/**
 * 
 */
package com.eventizer.services.event;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import javax.persistence.Query;
import com.eventizer.entity.common.Event;
import com.eventizer.entity.common.EventMaster;
import com.eventizer.entity.common.SearchCriteria;
import com.eventizer.entity.common.Status;
import com.eventizer.repository.repositories.EventJpaRepository;

/**
 * @author shysatya
 *
 */
@Service("eventService")
public class EventServiceImpl implements EventService {

	@Autowired
	@Qualifier(value = "eventJpaRepo")
	EventJpaRepository er;

	  @PersistenceContext
	    private EntityManager entityManager;
	 
	    
	  
	@Override
	public List<Event> getAllEvents() {

		return er.findAll();
	}

	@Override
	public Event getEventById(long eventId) {
		Event obj = er.findOne(eventId);
		return obj;
	}

	@Override
	public boolean addEvent(Event event) {
		er.save(event);
		return true;
	}

	@Override
	public void updateEvent(Event event) {

	}

	@Override
	public void deleteEvent(int EventId) {

	}

	@Override
	public List<Event> getEventByDate(Date date) {
		List<Event> obj = er.findByEventDate(date);

		return obj;
	}
	@Override
	public List<Event> getEventByDateAndTime(Date date, Date startTime, Date endTime) {
		
		List<Event> obj = er.findByEventDateAndStartTimeAndEndTime(date, startTime, endTime);
		
		return obj;
	}
	
	  public List<Event> searchUser(List<SearchCriteria> params) throws ParseException {
	        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
	        CriteriaQuery<Event> query = builder.createQuery(Event.class);
	        Root r = query.from(Event.class);
	 
	        Predicate predicate = builder.conjunction();
	        
	        for (SearchCriteria param : params) {
	        	//2018-01-13 14:12:00.0
	        	System.out.println(param.getValue());
	            if (param.getOperation().equalsIgnoreCase(">")) {
	                predicate = builder.and(predicate, 
	                  builder.greaterThanOrEqualTo(r.get(param.getKey()), 
	                  formatter(param.getValue().toString())));
	            } else if (param.getOperation().equalsIgnoreCase("<")) {
	                predicate = builder.and(predicate, 
	                  builder.lessThanOrEqualTo(r.get(param.getKey()), 
	                		  formatter(param.getValue().toString())));
	            } else if (param.getOperation().equalsIgnoreCase(":")) {
	                if (r.get(param.getKey()).getJavaType() == String.class) {
	                    predicate = builder.and(predicate, 
	                      builder.like(r.get(param.getKey()), 
	                      "%" + param.getValue() + "%"));
	                } else {
	                    predicate = builder.and(predicate, 
	                      builder.equal(r.get(param.getKey()), formatter(param.getValue().toString())));
	                }
	            }
	        }
	        query.where(predicate);
	 
	        List<Event> result = entityManager.createQuery(query).getResultList();
	        return result;
	    }
	  public Date formatter(String date) throws ParseException{

			DateFormat readFormat = new SimpleDateFormat(
		            "EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);	   
			DateFormat writeFormat= new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
			
			DateFormat readFinal= new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");

			Date date1 = null;
			try {
			    date1 = readFormat.parse(date);
			} catch (ParseException e) {
			    e.printStackTrace();
			}

			if (date1 != null) {
			    String formattedDate = writeFormat.format(date1);
		    	System.out.println(formattedDate);
		    	
		    	return readFinal.parse(formattedDate);

			}
			return null;
		}

	@Override
	public List<EventMaster> findByDateWithIntervals(Date date, Date endTime, Date startTime) throws ParseException {
		Query query =  
				entityManager.createQuery(
			"SELECT eM FROM EventMaster eM WHERE  eM.id NOT IN(SELECT masterKey from Event e where e.startTime BETWEEN  :startTime AND :endTime"
				+ " OR e.endTime BETWEEN :startTime AND :endTime)")
				
		 .setParameter("startTime", formatter(startTime.toString()))
		 .setParameter("endTime", formatter(endTime.toString()));
		 List<EventMaster> obj = query.getResultList();
		 
		return obj;
	}
	
	public List<EventMaster> findByStatusQuery(Status status){
		
		Query query  = entityManager.createQuery(
				"SELECT e from EventMaster e where e.id IN (SELECT masterKey FROM StatusDTO st where st.status = :status)")
				.setParameter("status", status);
		List<EventMaster> obj = query.getResultList();
		
		return obj;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
