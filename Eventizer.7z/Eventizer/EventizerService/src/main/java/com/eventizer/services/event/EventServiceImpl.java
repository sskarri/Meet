/**
 * 
 */
package com.eventizer.services.event;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eventizer.entity.common.Accessories;
import com.eventizer.entity.common.Event;
import com.eventizer.repository.repositories.AccessoriesRepository;
import com.eventizer.repository.repositories.EventRepository;

/**
 * @author shysatya
 *
 */
@Service("eventService")
public class EventServiceImpl implements EventService{

	/* (non-Javadoc)
	 * @see com.eventizer.services.event.EventService#saveEvent()
	 */
	
	@Autowired
	public EventRepository eventRepository;
	
	@Autowired
	public AccessoriesRepository acc;
	
	@Override
	public void saveEvent(Event event) {
		
		List<Accessories> al = new ArrayList<Accessories>();
		event.getAllowedAccessories().forEach(e -> {
			
			al.add(acc.findByaccessoryId(e));
			
		});
		System.out.println(al);
		eventRepository.save(event);
		 
		
	}

	/* (non-Javadoc)
	 * @see com.eventizer.services.event.EventService#deleteEvent()
	 */
	@Override
	public void deleteEvent(int id) {
		
		eventRepository.delete(id);
	}

	/* (non-Javadoc)
	 * @see com.eventizer.services.event.EventService#updateEvent()
	 */
	@Override
	public void updateEvent(Event event) {
		
		eventRepository.save(event);
	}

	
	
}
