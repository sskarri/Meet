/**
 * 
 */
package com.eventizer.services.event;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eventizer.entity.common.EventMaster;
import com.eventizer.repository.repositories.EventMasterRepository;

/**
 * @author shysatya
 *
 */
@Service("eventMasterService")
public class EventMasterServiceImpl implements EventMasterService{

	@Autowired
	public EventMasterRepository emr;
	
	@Override
	public List<EventMaster> getAllData() {
		
		
		return null;
	}

	@Override
	public EventMaster getEventMasterById(long masterId) {
		EventMaster master = emr.findOne(masterId);
		return master;
	}

	@Override
	public boolean addEventMaster(EventMaster event) {
		
		emr.save(event);
		return true;
	}

	@Override
	public void updateEventMaster(EventMaster event) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEventMaster(int masterId) {
		// TODO Auto-generated method stub
		
	}

}
