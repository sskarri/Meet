/**
 * 
 */
package com.eventizer.services.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eventizer.entity.common.Accessories;
import com.eventizer.repository.repositories.AccessoriesRepository;

/**
 * @author shysatya
 *
 */
@Service("accessoryService")
public class AccessoryServiceImpl implements AccessoryService{
	
	@Autowired
	AccessoriesRepository acc;

	@Override
	public void saveAccessory(Accessories accessory) {
		
		acc.save(accessory);
	}

	@Override
	public void deleteAccessory(int id) {
		
		acc.delete(id);
	}

	@Override
	public void updateAccessory(Accessories accessory) {
		acc.save(accessory);
	}

	
	
}
