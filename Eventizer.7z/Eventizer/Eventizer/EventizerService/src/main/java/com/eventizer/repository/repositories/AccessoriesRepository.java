/**
 * 
 */
package com.eventizer.repository.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.eventizer.entity.common.Accessories;

/**
 * @author shysatya
 *
 */
@Repository
public interface AccessoriesRepository extends CrudRepository<Accessories,Integer>{

		
	public Accessories findByaccessoryId(int id);
	
}
