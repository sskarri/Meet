/**
 * 
 */
package com.eventizer.services.event;

import org.springframework.stereotype.Component;

import com.eventizer.entity.common.Accessories;

/**
 * @author shysatya
 *
 */
@Component
public interface AccessoryService {

	public void saveAccessory(Accessories accessory);
	
	public void deleteAccessory(int id);
	
	public void updateAccessory(Accessories accessory);
	
}
