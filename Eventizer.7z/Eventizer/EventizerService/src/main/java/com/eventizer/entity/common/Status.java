/**
 * 
 */
package com.eventizer.entity.common;

/**
 * @author shysatya
 *
 */
public enum Status {
	
	AVAILABLE,BOOKED;

}
