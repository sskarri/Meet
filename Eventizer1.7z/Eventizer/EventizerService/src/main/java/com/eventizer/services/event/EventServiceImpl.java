/**
 * 
 */
package com.eventizer.services.event;

import org.springframework.beans.factory.annotation.Autowired;
import com.eventizer.entity.common.Event;
import com.eventizer.repository.eventrepository.EventRepository;

/**
 * @author shysatya
 *
 */
public class EventServiceImpl implements EventService{

	/* (non-Javadoc)
	 * @see com.eventizer.services.event.EventService#saveEvent()
	 */
	
	@Autowired
	public EventRepository eventRepository;
	
	@Override
	public void saveEvent(Event event) {
		
		eventRepository.save(event);
	}

	/* (non-Javadoc)
	 * @see com.eventizer.services.event.EventService#deleteEvent()
	 */
	@Override
	public void deleteEvent(int id) {
		
		eventRepository.delete(id);
	}

	/* (non-Javadoc)
	 * @see com.eventizer.services.event.EventService#updateEvent()
	 */
	@Override
	public void updateEvent(Event event) {
		
		eventRepository.save(event);
	}

	
	
}
