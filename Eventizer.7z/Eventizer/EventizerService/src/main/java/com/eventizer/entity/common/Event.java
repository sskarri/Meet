/**
 * 
 */
package com.eventizer.entity.common;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author shysatya
 *
 */
@Entity
@Table(name="event")
public class Event{

	public Event(){
		
	}
	  @Id
	  @Column(name="entity_id")
		 @GeneratedValue(strategy= GenerationType.IDENTITY)
		public int id;
	@Column(name="eventName")
	private String eventName;
	
	@CreatedDate
	private Date eventCreatedDate;

	@LastModifiedDate
	private Date eventModifiedDate;
	
	@Column(name="eventDescription")
	private String eventDescription;
	
	@OneToMany(targetEntity=Event.class, fetch=FetchType.EAGER)
	private Collection<Integer> allowedAccessories;
	
	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return eventName;
	}

	/**
	 * @param eventName the eventName to set
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	/**
	 * @return the eventCreatedDate
	 */
	public Date getEventCreatedDate() {
		return eventCreatedDate;
	}

	/**
	 * @param eventCreatedDate the eventCreatedDate to set
	 */
	public void setEventCreatedDate(Date eventCreatedDate) {
		this.eventCreatedDate = eventCreatedDate;
	}

	/**
	 * @return the eventModifiedDate
	 */
	public Date getEventModifiedDate() {
		return eventModifiedDate;
	}

	/**
	 * @param eventModifiedDate the eventModifiedDate to set
	 */
	public void setEventModifiedDate(Date eventModifiedDate) {
		this.eventModifiedDate = eventModifiedDate;
	}

	/**
	 * @return the eventDescription
	 */
	public String getEventDescription() {
		return eventDescription;
	}

	/**
	 * @param eventDescription the eventDescription to set
	 */
	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	/**
	 * @return the allowedAccessories
	 */
	public Collection<Integer> getAllowedAccessories() {
		return allowedAccessories;
	}

	/**
	 * @param allowedAccessories the allowedAccessories to set
	 */
	public void setAllowedAccessories(Collection<Integer> allowedAccessories) {
		this.allowedAccessories = allowedAccessories;
	}

	/**
	 * @return the startDate
	 */
    //@JsonSerialize(using = JsonDateSerializer.class)
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
    //@JsonDeserialize(using = JsonDateDeSerializer.class)
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
   // @JsonSerialize(using = JsonDateSerializer.class)
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
    //@JsonDeserialize(using = JsonDateDeSerializer.class)
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the duration
	 */
	public long getDuration() {
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(long duration) {
		this.duration = duration;
	}

	//@JsonSerialize(using=CustomDateSerializer.class)
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private Date startDate;
	//@JsonSerialize(using=CustomDateSerializer.class)
	 @JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private Date endDate;
	
	private long duration;
	
	
	
	
	
	
}
