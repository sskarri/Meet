/**
 * 
 */
package com.eventizer.entity.common;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;


/**
 * @author shysatya
 *
 */
@MappedSuperclass
public class EntityId {
	
	  @Id
	 @GeneratedValue(strategy= GenerationType.IDENTITY)
	public long id;

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param l the id to set
	 */
	public void setId(long l) {
		this.id = l;
	}
	

}
