/**
 * 
 */
package com.eventizer.controller.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.eventizer.entity.common.Accessories;
import com.eventizer.services.event.AccessoryService;

/**
 * @author shysatya
 *
 */
@RestController
@RequestMapping("/acc")
public class AccessoriesController {

		
	@Autowired
	AccessoryService accServ;
	
		@RequestMapping(value= "/add",method=RequestMethod.POST)
		public ResponseEntity<String> add(@RequestBody Accessories acc){
			
			accServ.saveAccessory(acc);
			
			return new ResponseEntity<>("Success",HttpStatus.CREATED);
		}
	
}
