/**
 * 
 */
package com.eventizer.controller.event;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.eventizer.entity.common.Event;
import com.eventizer.entity.common.EventMaster;
import com.eventizer.entity.common.SearchCriteria;
import com.eventizer.entity.common.SlotMapper;
import com.eventizer.entity.common.Status;
import com.eventizer.entity.common.StatusDTO;
import com.eventizer.repository.repositories.StatusMaster;
import com.eventizer.services.event.EventMasterService;
import com.eventizer.services.event.EventService;

/**
 * @author shysatya
 *
 */
@RestController
@RequestMapping("/events")
public class EventController {

	public static final Logger logger = LoggerFactory.getLogger(EventController.class);

	@Autowired
	public EventService es;

	@Autowired
	public EventMasterService ems;
	

	@Autowired
	public StatusMaster stm;

	@RequestMapping(value = "/addEvent/", method = RequestMethod.POST)
	public ResponseEntity<?> createEvent(@RequestBody Event event, UriComponentsBuilder ucBuilder) {
		logger.info("Creating Event : {}", event);

		long key = event.getMasterKey();
		EventMaster master = ems.getEventMasterById(key);

		event.setMaster(master);
		event.setStatus(Status.BOOKED);
		es.addEvent(event);
		
		StatusDTO dto = stm.findOne(master.getId());
		dto.setDate(event.getEventDate());
		dto.setStatus(Status.BOOKED);
		
		stm.save(dto);
		

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/events/event/{id}").buildAndExpand(event.getId()).toUri());
		return new ResponseEntity<String>(headers, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/getAll", method = RequestMethod.GET)
	public List<Event> getAllEvents() {

		List<Event> events = es.getAllEvents();

		return  events;

	}

	@RequestMapping(value = "/getByDate", method = RequestMethod.POST)
	public ResponseEntity<List<Event>> getEventByDate(
			@RequestBody SlotMapper  data) {
		
		List<Event> e = es.getEventByDate(data.getDate());

		return new ResponseEntity<List<Event>>(e, HttpStatus.FOUND);
	}
	
	@RequestMapping(value = "/getByDateAndTime", method = RequestMethod.POST)
	public ResponseEntity<List<Event>> getEventByDateAndTimeSlot(
			@RequestBody SlotMapper  data) {
		
		
		List<Event> e = es.getEventByDateAndTime(data.getDate(),data.getStartTime(),data.getEndTime());

		return new ResponseEntity<List<Event>>(e, HttpStatus.FOUND);
	}
	
	
	  @RequestMapping(method = RequestMethod.POST, value = "/searchEvent")
	    
	    public List<Event> findAll(@RequestBody SlotMapper data) throws ParseException {
	        List<SearchCriteria> params = new ArrayList<SearchCriteria>();
	        if (data != null) {
	            //Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)(\\w+?),");
	           // Matcher matcher = pattern.matcher(search + ",");
	           // while (matcher.find()) {
	          //      params.add(new SearchCriteria(matcher.group(1), 
	            //      matcher.group(2), matcher.group(3)));
	           // }
	        	params.add(new SearchCriteria("eventDate", ":", data.getDate()));
	        	
	 	      //  params.add(new SearchCriteria("startTime", "<", data.getStartTime()));
	 	      //  params.add(new SearchCriteria("endTime", "<", data.getEndTime()));
	 	    //   params.add(new SearchCriteria("startTime", ">", formatter(data.getStartTime().toString())));
	 	    //    params.add(new SearchCriteria("endTime", ">", formatter(data.getEndTime().toString())));
	 	        
	        }
	        return es.searchUser(params);
	    }
	
	
		@RequestMapping(value = "/getSpecific", method = RequestMethod.POST)
		public ResponseEntity<List<EventMaster>> findByDateWithIntervals(
				@RequestBody SlotMapper  data) throws ParseException {
			
			List<EventMaster> e = es.findByDateWithIntervals(data.getDate(),data.getEndTime(),data.getStartTime());
			List<EventMaster> e1 = es.findByStatusQuery(Status.AVAILABLE);
			 
			
		//	e.addAll(e1);
			
		
			
			return new ResponseEntity<List<EventMaster>>(e, HttpStatus.FOUND);
		}
	
	
	
}
