/**
 * 
 */
package com.eventizer.entity.common;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author shysatya
 *
 */
@Entity
@Table(name="accessories")
public class Accessories{

	public Accessories(){
		
	}
	@Id
	@Column(name="accessoryId")
	 @GeneratedValue(strategy= GenerationType.IDENTITY)
	private int accessoryId;
	
	@Column(name="name")
	private String name;
	
	

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
}
