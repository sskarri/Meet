/**
 * 
 */
package com.eventizer.services.event;

import org.springframework.stereotype.Component;

import com.eventizer.entity.common.Event;

/**
 * @author shysatya
 *
 */
@Component
public interface  EventService {
	
	public void saveEvent(Event event);
	
	public void deleteEvent(int id);
	
	public void updateEvent(Event event);

		
}
