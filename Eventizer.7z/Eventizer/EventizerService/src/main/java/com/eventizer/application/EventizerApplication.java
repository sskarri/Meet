/**
 * 
 */
package com.eventizer.application;

import java.util.Set; 

import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * @author shysatya
 *
 */
@SpringBootApplication(scanBasePackages={"com.eventizer.*"})
@EnableJpaRepositories(basePackages = "com.eventizer.repository.*")
public class EventizerApplication implements ServletContainerInitializer{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(EventizerApplication.class, args);

	}

	@Override
	public void onStartup(Set<Class<?>> arg0, ServletContext arg1) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
