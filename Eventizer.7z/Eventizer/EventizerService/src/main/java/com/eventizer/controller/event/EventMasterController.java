/**
 * 
 */
package com.eventizer.controller.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.eventizer.entity.common.EventMaster;
import com.eventizer.entity.common.Status;
import com.eventizer.entity.common.StatusDTO;
import com.eventizer.repository.repositories.StatusMaster;
import com.eventizer.services.event.EventMasterService;
 
/**
 * @author shysatya
 *
 */
@RestController
@RequestMapping("/masters")
public class EventMasterController {

	public static final Logger logger = LoggerFactory.getLogger(EventMasterController.class);

	
	@Autowired
	public EventMasterService ems;
	
	@Autowired
	public StatusMaster stm;
	
	@RequestMapping(value = "/addMaster" , method=RequestMethod.POST)
	public ResponseEntity<String> addMaster(@RequestBody EventMaster master ,UriComponentsBuilder ucBuilder){
		
		logger.info("Creating master : {}", master);
		ems.addEventMaster(master);
		StatusDTO dto = new StatusDTO(master.getEventCreatedDate(),Status.AVAILABLE,master.getId());
		stm.save(dto);
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/masters/master/{id}").buildAndExpand(master.getId()).toUri());
		return new ResponseEntity<String>(headers, HttpStatus.CREATED);
	}
	
	
	
	
}
