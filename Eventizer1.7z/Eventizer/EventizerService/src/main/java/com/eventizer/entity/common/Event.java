/**
 * 
 */
package com.eventizer.entity.common;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author shysatya
 *
 */
@Document
public class Event extends EntityId{

	@Indexed
	private String eventName;
	
	@CreatedDate
	private Date eventCreatedDate;

	@LastModifiedDate
	private Date eventModifiedDate;
	
	private String eventDescription;
	
	private List<Accessories> allowedAccessories;
	
	@JsonSerialize(using=CustomDateSerializer.class)
	private Date startDate;
	
	@JsonSerialize(using=CustomDateSerializer.class)
	private Date endDate;
	
	private long duration;
	
	
	
	
}
